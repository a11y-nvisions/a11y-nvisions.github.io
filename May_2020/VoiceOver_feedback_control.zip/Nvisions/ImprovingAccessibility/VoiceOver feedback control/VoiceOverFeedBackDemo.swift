import UIKit

class VoiceOverFeedBackDemo: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameButton: UIButton!
    @IBOutlet weak var nameLabel2: UILabel!
    @IBOutlet weak var nameButton2: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    nameButton.addTarget(self, action: #selector(btnOnClick(_:)), for: .touchUpInside)
        nameButton2.addTarget(self, action: #selector(btnOnClick2(_:)), for: .touchUpInside)
        }

    @objc func btnOnClick(_ sender: UIButton)      {
        if nameLabel.text == "저의 이름은 널리입니다." {
            nameLabel.text = "저의 이름은 접근성입니다."
        } else {
            nameLabel.text = "저의 이름은 널리입니다."
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            UIAccessibility.post(notification: .announcement, argument: self.nameLabel.text)
        }
    }
    
    @objc func btnOnClick2(_ sender: UIButton)      {
        if nameLabel2.text == "저의 이름은 널리입니다." {
            nameLabel2.text = "저의 이름은 접근성입니다."
        } else {
            nameLabel2.text = "저의 이름은 널리입니다."
        }
    }


}


