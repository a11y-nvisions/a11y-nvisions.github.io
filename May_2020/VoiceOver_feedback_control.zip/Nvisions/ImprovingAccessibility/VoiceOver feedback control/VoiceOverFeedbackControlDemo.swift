//
//  ViewController.swift
//  Chapter6
//
//  Created by Thornuko on 7/15/17.
//  Copyright © 2017 Innovativeware. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameButton: UIButton!

    @IBAction func showName(sender: AnyObject) {
        if nameLabel.text == "저의 이름은 타미입니다." {
            nameLabel.text = "저의 이름은 접근성입니다."
        } else {
            nameLabel.text = "저의 이름은 타미입니다."
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            UIAccessibility.post(notification: .announcement, argument: self.nameLabel.text)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        nameButton.accessibilityTraits = .button    
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

