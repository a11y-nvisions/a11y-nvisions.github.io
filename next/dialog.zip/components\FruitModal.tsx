import React, { useState, useEffect, useRef } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { Cross2Icon } from '@radix-ui/react-icons';
import 'tailwindcss/tailwind.css';

const fruits = ['사과', '바나나', '체리', '포도', '오렌지'];

interface FruitModalProps {
  onSelect: (fruit: string) => void;
}

const FruitModal: React.FC<FruitModalProps> = ({ onSelect }) => {
  const [selectedFruit, setSelectedFruit] = useState<string | null>(null);
  const [focusedIndex, setFocusedIndex] = useState<number>(0);
  const listRef = useRef<HTMLUListElement>(null);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    switch (event.key) {
      case 'Enter':
      case ' ':
        setSelectedFruit(fruits[index]);
        onSelect(fruits[index]);
        break;
      case 'ArrowUp':
        setFocusedIndex((prevIndex) => (prevIndex > 0 ? prevIndex - 1 : fruits.length - 1));
        break;
      case 'ArrowDown':
        setFocusedIndex((prevIndex) => (prevIndex < fruits.length - 1 ? prevIndex + 1 : 0));
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    const list = listRef.current;
    if (list) {
      const items = list.querySelectorAll('button');
      if (items[focusedIndex]) {
        (items[focusedIndex] as HTMLElement).focus();
      }
    }
  }, [focusedIndex]);

  return (
    <Dialog.Root>
      <Dialog.Trigger asChild>
        <button className="bg-blue-500 text-white px-4 py-2 rounded">
          좋아하는 과일 고르기
        </button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black bg-opacity-50" />
        <Dialog.Content className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white p-6 rounded-lg shadow-lg w-11/12 max-w-md">
          <Dialog.Title className="text-xl font-bold mb-4">좋아하는 과일을 선택하세요</Dialog.Title>
          <Dialog.Description className="mb-4">
            아래 목록에서 좋아하는 과일을 선택하세요.
          </Dialog.Description>
          <ul className="list-disc pl-5 mb-4" role="listbox" aria-multiselectable="false" ref={listRef}>
            {fruits.map((fruit, index) => (
              <li key={fruit} role="none">
                <button
                  role="option"
                  aria-selected={selectedFruit === fruit}
                  tabIndex={selectedFruit === fruit || (!selectedFruit && index === 0) ? 0 : -1}
                  className={`w-full text-left px-4 py-2 rounded cursor-pointer ${selectedFruit === fruit ? 'bg-blue-200' : 'bg-gray-200'} ${focusedIndex === index ? 'outline-none ring-2 ring-blue-500' : ''}`}
                  onClick={() => {
                    setSelectedFruit(fruit);
                    onSelect(fruit);
                  }}
                  onKeyDown={(event) => handleKeyDown(event, index)}
                  onFocus={() => setFocusedIndex(index)}
                >
                  {fruit}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex justify-end gap-4">
            <Dialog.Close asChild>
              <button
                className="bg-green-500 text-white px-4 py-2 rounded"
                onClick={() => selectedFruit && onSelect(selectedFruit)}
              >
                확인
              </button>
            </Dialog.Close>
            <Dialog.Close asChild>
              <button className="bg-red-500 text-white px-4 py-2 rounded" aria-label="Close">
                <Cross2Icon />
              </button>
            </Dialog.Close>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
};

export default FruitModal;