import Head from 'next/head';
import { useState } from 'react';
import FruitModal from '../components/FruitModal';

const Home: React.FC = () => {
  const [selectedFruit, setSelectedFruit] = useState<string | null>(null);

  return (
    <div>
      <Head>
        <title>과일 선택 모달</title>
      </Head>
      <main className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
        <h1 className="text-3xl font-bold mb-6">과일 선택 모달</h1>
        <FruitModal onSelect={setSelectedFruit} />
        {selectedFruit && (
          <p className="mt-4 text-xl">
            선택된 과일: <span className="font-bold">{selectedFruit}</span>
          </p>
        )}
      </main>
    </div>
  );
};

export default Home;